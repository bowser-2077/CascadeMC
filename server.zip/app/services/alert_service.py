import asyncio
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_

from app.models.alert import Alert, AlertSeverity, AlertStatus
from app.models.device import Device
from app.models.metric import Metric

logger = logging.getLogger(__name__)

class AlertService:
    def __init__(self, db: Session):
        self.db = db
    
    def check_alerts(self, device_id: Optional[int] = None) -> List[Alert]:
        """Check for alert conditions based on latest metrics"""
        triggered_alerts = []
        
        # Get active alert rules
        query = self.db.query(Alert).filter(Alert.status == AlertStatus.ACTIVE)
        if device_id:
            query = query.filter(Alert.device_id == device_id)
        
        active_alerts = query.all()
        
        for alert_rule in active_alerts:
            try:
                # Get latest metric for this alert
                latest_metric = self.db.query(Metric).filter(
                    and_(
                        Metric.device_id == alert_rule.device_id,
                        Metric.metric_name == alert_rule.metric_name
                    )
                ).order_by(Metric.timestamp.desc()).first()
                
                if not latest_metric:
                    continue
                
                # Check if alert condition is met
                current_value = latest_metric.value
                threshold_value = alert_rule.threshold_value
                operator = alert_rule.operator
                
                condition_met = self._evaluate_condition(current_value, threshold_value, operator)
                
                if condition_met:
                    # Update existing alert or create new one
                    existing_alert = self.db.query(Alert).filter(
                        and_(
                            Alert.device_id == alert_rule.device_id,
                            Alert.metric_name == alert_rule.metric_name,
                            Alert.status == AlertStatus.ACTIVE,
                            Alert.title == alert_rule.title
                        )
                    ).first()
                    
                    if existing_alert:
                        # Update current value
                        existing_alert.current_value = current_value
                        existing_alert.triggered_at = datetime.utcnow()
                        triggered_alerts.append(existing_alert)
                    else:
                        # Create new alert instance
                        new_alert = Alert(
                            device_id=alert_rule.device_id,
                            title=alert_rule.title,
                            description=alert_rule.description,
                            severity=alert_rule.severity,
                            status=AlertStatus.ACTIVE,
                            metric_name=alert_rule.metric_name,
                            threshold_value=alert_rule.threshold_value,
                            current_value=current_value,
                            operator=alert_rule.operator
                        )
                        self.db.add(new_alert)
                        triggered_alerts.append(new_alert)
                        
                        logger.info(f"Alert triggered: {alert_rule.title} for device {alert_rule.device_id}")
                
            except Exception as e:
                logger.error(f"Error checking alert {alert_rule.id}: {e}")
                continue
        
        try:
            self.db.commit()
        except Exception as e:
            logger.error(f"Error committing alerts: {e}")
            self.db.rollback()
        
        return triggered_alerts
    
    def _evaluate_condition(self, current_value: float, threshold_value: float, operator: str) -> bool:
        """Evaluate alert condition based on operator"""
        try:
            if operator == '>':
                return current_value > threshold_value
            elif operator == '<':
                return current_value < threshold_value
            elif operator == '>=':
                return current_value >= threshold_value
            elif operator == '<=':
                return current_value <= threshold_value
            elif operator == '==':
                return abs(current_value - threshold_value) < 0.001  # Small tolerance for floating point
            else:
                logger.warning(f"Unknown operator: {operator}")
                return False
        except Exception as e:
            logger.error(f"Error evaluating condition: {e}")
            return False
    
    def resolve_alert(self, alert_id: int) -> bool:
        """Resolve an alert"""
        try:
            alert = self.db.query(Alert).filter(Alert.id == alert_id).first()
            if not alert:
                return False
            
            alert.status = AlertStatus.RESOLVED
            alert.resolved_at = datetime.utcnow()
            self.db.commit()
            
            logger.info(f"Alert {alert_id} resolved")
            return True
            
        except Exception as e:
            logger.error(f"Error resolving alert {alert_id}: {e}")
            self.db.rollback()
            return False
    
    def acknowledge_alert(self, alert_id: int) -> bool:
        """Acknowledge an alert"""
        try:
            alert = self.db.query(Alert).filter(Alert.id == alert_id).first()
            if not alert:
                return False
            
            alert.status = AlertStatus.ACKNOWLEDGED
            alert.acknowledged_at = datetime.utcnow()
            self.db.commit()
            
            logger.info(f"Alert {alert_id} acknowledged")
            return True
            
        except Exception as e:
            logger.error(f"Error acknowledging alert {alert_id}: {e}")
            self.db.rollback()
            return False
    
    def get_active_alerts_count(self, device_id: Optional[int] = None) -> Dict[str, int]:
        """Get count of active alerts by severity"""
        query = self.db.query(Alert).filter(Alert.status == AlertStatus.ACTIVE)
        if device_id:
            query = query.filter(Alert.device_id == device_id)
        
        alerts = query.all()
        
        counts = {
            'total': len(alerts),
            'critical': len([a for a in alerts if a.severity == AlertSeverity.CRITICAL]),
            'warning': len([a for a in alerts if a.severity == AlertSeverity.WARNING]),
            'info': len([a for a in alerts if a.severity == AlertSeverity.INFO])
        }
        
        return counts
    
    def cleanup_old_metrics(self, days_to_keep: int = 30) -> int:
        """Clean up old metrics to prevent database bloat"""
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days_to_keep)
            
            deleted_count = self.db.query(Metric).filter(
                Metric.timestamp < cutoff_date
            ).delete()
            
            self.db.commit()
            logger.info(f"Cleaned up {deleted_count} old metrics")
            return deleted_count
            
        except Exception as e:
            logger.error(f"Error cleaning up old metrics: {e}")
            self.db.rollback()
            return 0
    
    def get_device_health_score(self, device_id: int) -> Dict[str, Any]:
        """Calculate device health score based on metrics and alerts"""
        try:
            device = self.db.query(Device).filter(Device.id == device_id).first()
            if not device:
                return {'score': 0, 'status': 'unknown'}
            
            # Base score starts at 100
            score = 100
            
            # Check if device is online
            if not device.is_online:
                score -= 50
            
            # Check for active alerts
            active_alerts = self.db.query(Alert).filter(
                and_(
                    Alert.device_id == device_id,
                    Alert.status == AlertStatus.ACTIVE
                )
            ).all()
            
            for alert in active_alerts:
                if alert.severity == AlertSeverity.CRITICAL:
                    score -= 30
                elif alert.severity == AlertSeverity.WARNING:
                    score -= 15
                elif alert.severity == AlertSeverity.INFO:
                    score -= 5
            
            # Check recent metrics for health indicators
            recent_time = datetime.utcnow() - timedelta(minutes=5)
            recent_metrics = self.db.query(Metric).filter(
                and_(
                    Metric.device_id == device_id,
                    Metric.timestamp >= recent_time
                )
            ).all()
            
            # Check CPU usage
            cpu_metrics = [m for m in recent_metrics if m.metric_name == 'cpu_usage_percent']
            if cpu_metrics:
                avg_cpu = sum(m.value for m in cpu_metrics) / len(cpu_metrics)
                if avg_cpu > 90:
                    score -= 20
                elif avg_cpu > 80:
                    score -= 10
            
            # Check memory usage
            mem_metrics = [m for m in recent_metrics if m.metric_name == 'memory_usage_percent']
            if mem_metrics:
                avg_mem = sum(m.value for m in mem_metrics) / len(mem_metrics)
                if avg_mem > 90:
                    score -= 20
                elif avg_mem > 80:
                    score -= 10
            
            score = max(0, score)  # Ensure score doesn't go below 0
            
            # Determine status
            if score >= 80:
                status = 'excellent'
            elif score >= 60:
                status = 'good'
            elif score >= 40:
                status = 'warning'
            else:
                status = 'critical'
            
            return {
                'score': score,
                'status': status,
                'active_alerts': len(active_alerts),
                'is_online': device.is_online
            }
            
        except Exception as e:
            logger.error(f"Error calculating health score for device {device_id}: {e}")
            return {'score': 0, 'status': 'error'}

# Singleton instance for use in background tasks
alert_service_instance = None

def get_alert_service(db: Session) -> AlertService:
    global alert_service_instance
    if alert_service_instance is None:
        alert_service_instance = AlertService(db)
    return alert_service_instance
