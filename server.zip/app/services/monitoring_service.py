import asyncio
import logging
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_

from app.models.device import Device
from app.models.metric import Metric
from app.services.alert_service import AlertService

logger = logging.getLogger(__name__)

class MonitoringService:
    def __init__(self, db: Session):
        self.db = db
        self.alert_service = AlertService(db)
    
    def update_device_status(self) -> Dict[str, int]:
        """Update device online/offline status based on last seen time"""
        updated_count = 0
        offline_threshold = datetime.utcnow() - timedelta(minutes=5)
        
        try:
            # Mark devices as offline if they haven't been seen recently
            devices_to_update = self.db.query(Device).filter(
                and_(
                    Device.is_online == True,
                    Device.last_seen < offline_threshold
                )
            ).all()
            
            for device in devices_to_update:
                device.is_online = False
                logger.info(f"Device {device.name} ({device.id}) marked as offline")
                updated_count += 1
            
            self.db.commit()
            
        except Exception as e:
            logger.error(f"Error updating device status: {e}")
            self.db.rollback()
        
        return {
            'devices_marked_offline': updated_count,
            'timestamp': datetime.utcnow()
        }
    
    def get_system_overview(self) -> Dict[str, Any]:
        """Get comprehensive system overview"""
        try:
            # Device statistics
            total_devices = self.db.query(Device).count()
            online_devices = self.db.query(Device).filter(Device.is_online == True).count()
            offline_devices = total_devices - online_devices
            
            # Alert statistics
            alert_counts = self.alert_service.get_active_alerts_count()
            
            # Recent metrics summary
            recent_time = datetime.utcnow() - timedelta(hours=1)
            recent_metrics = self.db.query(Metric).filter(
                Metric.timestamp >= recent_time
            ).count()
            
            # Device health distribution
            health_distribution = self._get_health_distribution()
            
            return {
                'devices': {
                    'total': total_devices,
                    'online': online_devices,
                    'offline': offline_devices,
                    'online_percentage': (online_devices / total_devices * 100) if total_devices > 0 else 0
                },
                'alerts': alert_counts,
                'metrics': {
                    'recent_count': recent_metrics,
                    'time_range_hours': 1
                },
                'health_distribution': health_distribution,
                'timestamp': datetime.utcnow()
            }
            
        except Exception as e:
            logger.error(f"Error getting system overview: {e}")
            return {
                'error': str(e),
                'timestamp': datetime.utcnow()
            }
    
    def _get_health_distribution(self) -> Dict[str, int]:
        """Get distribution of device health scores"""
        distribution = {
            'excellent': 0,
            'good': 0,
            'warning': 0,
            'critical': 0,
            'unknown': 0
        }
        
        try:
            devices = self.db.query(Device).all()
            
            for device in devices:
                health = self.alert_service.get_device_health_score(device.id)
                status = health.get('status', 'unknown')
                distribution[status] += 1
                
        except Exception as e:
            logger.error(f"Error getting health distribution: {e}")
        
        return distribution
    
    def get_device_metrics_summary(self, device_id: int, hours: int = 24) -> Dict[str, Any]:
        """Get detailed metrics summary for a specific device"""
        try:
            device = self.db.query(Device).filter(Device.id == device_id).first()
            if not device:
                return {'error': 'Device not found'}
            
            # Get metrics in time range
            time_threshold = datetime.utcnow() - timedelta(hours=hours)
            metrics = self.db.query(Metric).filter(
                and_(
                    Metric.device_id == device_id,
                    Metric.timestamp >= time_threshold
                )
            ).all()
            
            # Group by metric name and calculate statistics
            metric_summary = {}
            for metric in metrics:
                if metric.metric_name not in metric_summary:
                    metric_summary[metric.metric_name] = {
                        'count': 0,
                        'values': [],
                        'unit': metric.unit,
                        'latest': None,
                        'avg': 0,
                        'min': float('inf'),
                        'max': float('-inf')
                    }
                
                summary = metric_summary[metric.metric_name]
                summary['count'] += 1
                summary['values'].append(metric.value)
                
                # Update min/max
                summary['min'] = min(summary['min'], metric.value)
                summary['max'] = max(summary['max'], metric.value)
                
                # Keep latest (metrics are ordered by timestamp desc in query)
                if summary['latest'] is None:
                    summary['latest'] = metric.value
            
            # Calculate averages
            for metric_name, summary in metric_summary.items():
                if summary['values']:
                    summary['avg'] = sum(summary['values']) / len(summary['values'])
                del summary['values']  # Remove raw values to reduce response size
            
            # Get device health
            health = self.alert_service.get_device_health_score(device_id)
            
            return {
                'device': {
                    'id': device.id,
                    'name': device.name,
                    'hostname': device.hostname,
                    'is_online': device.is_online,
                    'last_seen': device.last_seen
                },
                'health': health,
                'metrics': metric_summary,
                'time_range_hours': hours,
                'timestamp': datetime.utcnow()
            }
            
        except Exception as e:
            logger.error(f"Error getting device metrics summary for {device_id}: {e}")
            return {'error': str(e)}
    
    def run_monitoring_cycle(self) -> Dict[str, Any]:
        """Run a complete monitoring cycle"""
        results = {
            'timestamp': datetime.utcnow(),
            'device_status_update': None,
            'alert_check': None,
            'system_overview': None
        }
        
        try:
            # Update device online/offline status
            results['device_status_update'] = self.update_device_status()
            
            # Check for new alerts
            triggered_alerts = self.alert_service.check_alerts()
            results['alert_check'] = {
                'triggered_alerts_count': len(triggered_alerts),
                'triggered_alerts': [
                    {
                        'id': alert.id,
                        'device_id': alert.device_id,
                        'title': alert.title,
                        'severity': alert.severity.value,
                        'current_value': alert.current_value
                    }
                    for alert in triggered_alerts
                ]
            }
            
            # Get system overview
            results['system_overview'] = self.get_system_overview()
            
            logger.info(f"Monitoring cycle completed: {results}")
            
        except Exception as e:
            logger.error(f"Error in monitoring cycle: {e}")
            results['error'] = str(e)
        
        return results

# Background task runner
class MonitoringBackgroundTask:
    def __init__(self, db_session_factory, interval_seconds: int = 60):
        self.db_session_factory = db_session_factory
        self.interval_seconds = interval_seconds
        self.running = False
        self.task = None
    
    async def start(self):
        """Start the background monitoring task"""
        if self.running:
            return
        
        self.running = True
        self.task = asyncio.create_task(self._monitoring_loop())
        logger.info("Background monitoring task started")
    
    async def stop(self):
        """Stop the background monitoring task"""
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
        logger.info("Background monitoring task stopped")
    
    async def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.running:
            try:
                # Get database session for this cycle
                db = self.db_session_factory()
                try:
                    monitoring_service = MonitoringService(db)
                    results = monitoring_service.run_monitoring_cycle()
                    logger.debug(f"Monitoring cycle results: {results}")
                finally:
                    db.close()
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
            
            # Wait for next cycle
            try:
                await asyncio.sleep(self.interval_seconds)
            except asyncio.CancelledError:
                break

# Global background task instance
background_task = None

def start_background_monitoring(db_session_factory, interval_seconds: int = 60):
    """Start the global background monitoring task"""
    global background_task
    if background_task is None:
        background_task = MonitoringBackgroundTask(db_session_factory, interval_seconds)
    
    # This would be started in an async context
    # await background_task.start()

def stop_background_monitoring():
    """Stop the global background monitoring task"""
    global background_task
    if background_task:
        # This would be stopped in an async context
        # await background_task.stop()
        background_task = None
