from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime

from app.main import get_db
from app.models.alert import Alert, AlertSeverity, AlertStatus
from app.models.device import Device

router = APIRouter()

# Pydantic models
class AlertBase(BaseModel):
    title: str
    description: Optional[str] = None
    severity: AlertSeverity
    metric_name: str
    threshold_value: float
    operator: str
    device_id: int

class AlertCreate(AlertBase):
    pass

class AlertUpdate(BaseModel):
    status: Optional[AlertStatus] = None
    acknowledged_at: Optional[datetime] = None

class AlertResponse(AlertBase):
    id: int
    current_value: float
    status: AlertStatus
    triggered_at: datetime
    resolved_at: Optional[datetime]
    acknowledged_at: Optional[datetime]
    metadata: Optional[str]

    class Config:
        from_attributes = True

class AlertRule(BaseModel):
    device_id: int
    metric_name: str
    threshold_value: float
    operator: str
    severity: AlertSeverity
    title: str
    description: Optional[str] = None

# Endpoints
@router.post("/alerts/", response_model=AlertResponse, status_code=status.HTTP_201_CREATED)
async def create_alert(alert: AlertCreate, db: Session = Depends(get_db)):
    # Verify device exists
    device = db.query(Device).filter(Device.id == alert.device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    db_alert = Alert(**alert.dict())
    db.add(db_alert)
    db.commit()
    db.refresh(db_alert)
    return db_alert

@router.get("/alerts/", response_model=List[AlertResponse])
async def get_alerts(
    device_id: Optional[int] = None,
    severity: Optional[AlertSeverity] = None,
    status: Optional[AlertStatus] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    query = db.query(Alert)
    
    if device_id:
        query = query.filter(Alert.device_id == device_id)
    
    if severity:
        query = query.filter(Alert.severity == severity)
    
    if status:
        query = query.filter(Alert.status == status)
    
    alerts = query.order_by(Alert.triggered_at.desc()).offset(skip).limit(limit).all()
    return alerts

@router.get("/alerts/{alert_id}", response_model=AlertResponse)
async def get_alert(alert_id: int, db: Session = Depends(get_db)):
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alert not found"
        )
    return alert

@router.put("/alerts/{alert_id}", response_model=AlertResponse)
async def update_alert(
    alert_id: int,
    alert_update: AlertUpdate,
    db: Session = Depends(get_db)
):
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alert not found"
        )
    
    update_data = alert_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(alert, field, value)
    
    if alert_update.status == AlertStatus.RESOLVED and not alert.resolved_at:
        alert.resolved_at = datetime.utcnow()
    
    if alert_update.status == AlertStatus.ACKNOWLEDGED and not alert.acknowledged_at:
        alert.acknowledged_at = datetime.utcnow()
    
    db.commit()
    db.refresh(alert)
    return alert

@router.delete("/alerts/{alert_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_alert(alert_id: int, db: Session = Depends(get_db)):
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alert not found"
        )
    
    db.delete(alert)
    db.commit()

@router.post("/alerts/check", response_model=List[AlertResponse])
async def check_alerts(
    device_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    # This endpoint would typically be called by a background job
    # For now, we'll return existing active alerts
    query = db.query(Alert).filter(Alert.status == AlertStatus.ACTIVE)
    
    if device_id:
        query = query.filter(Alert.device_id == device_id)
    
    alerts = query.all()
    return alerts

@router.get("/alerts/summary")
async def get_alerts_summary(db: Session = Depends(get_db)):
    # Count alerts by severity and status
    summary = {
        "total": db.query(Alert).count(),
        "active": db.query(Alert).filter(Alert.status == AlertStatus.ACTIVE).count(),
        "acknowledged": db.query(Alert).filter(Alert.status == AlertStatus.ACKNOWLEDGED).count(),
        "resolved": db.query(Alert).filter(Alert.status == AlertStatus.RESOLVED).count(),
        "by_severity": {
            "critical": db.query(Alert).filter(Alert.severity == AlertSeverity.CRITICAL, Alert.status == AlertStatus.ACTIVE).count(),
            "warning": db.query(Alert).filter(Alert.severity == AlertSeverity.WARNING, Alert.status == AlertStatus.ACTIVE).count(),
            "info": db.query(Alert).filter(Alert.severity == AlertSeverity.INFO, Alert.status == AlertStatus.ACTIVE).count()
        }
    }
    
    return summary
