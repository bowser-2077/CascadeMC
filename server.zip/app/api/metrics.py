from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime, timedelta

from app.main import get_db
from app.models.device import Device
from app.models.metric import Metric

router = APIRouter()

# Pydantic models
class MetricBase(BaseModel):
    metric_name: str
    metric_type: str
    value: float
    unit: Optional[str] = None
    metadata: Optional[str] = None

class MetricCreate(MetricBase):
    device_id: int

class MetricResponse(MetricBase):
    id: int
    device_id: int
    timestamp: datetime
    created_at: datetime

    class Config:
        from_attributes = True

class MetricBatch(BaseModel):
    device_id: int
    metrics: List[MetricBase]

# Endpoints
@router.post("/metrics/", response_model=MetricResponse, status_code=status.HTTP_201_CREATED)
async def create_metric(metric: MetricCreate, db: Session = Depends(get_db)):
    # Verify device exists
    device = db.query(Device).filter(Device.id == metric.device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    db_metric = Metric(**metric.dict())
    db.add(db_metric)
    
    # Update device last_seen and online status
    device.is_online = True
    device.last_seen = datetime.utcnow()
    
    db.commit()
    db.refresh(db_metric)
    return db_metric

@router.post("/metrics/batch", status_code=status.HTTP_201_CREATED)
async def create_metrics_batch(batch: MetricBatch, db: Session = Depends(get_db)):
    # Verify device exists
    device = db.query(Device).filter(Device.id == batch.device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    # Create metrics
    db_metrics = []
    for metric_data in batch.metrics:
        db_metric = Metric(
            device_id=batch.device_id,
            **metric_data.dict()
        )
        db.add(db_metric)
        db_metrics.append(db_metric)
    
    # Update device status
    device.is_online = True
    device.last_seen = datetime.utcnow()
    
    db.commit()
    
    return {
        "status": "success",
        "metrics_count": len(db_metrics),
        "device_id": batch.device_id
    }

@router.get("/metrics/", response_model=List[MetricResponse])
async def get_metrics(
    device_id: Optional[int] = None,
    metric_type: Optional[str] = None,
    metric_name: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    hours: int = 24,
    db: Session = Depends(get_db)
):
    query = db.query(Metric)
    
    if device_id:
        query = query.filter(Metric.device_id == device_id)
    
    if metric_type:
        query = query.filter(Metric.metric_type == metric_type)
    
    if metric_name:
        query = query.filter(Metric.metric_name == metric_name)
    
    # Filter by time range
    time_threshold = datetime.utcnow() - timedelta(hours=hours)
    query = query.filter(Metric.timestamp >= time_threshold)
    
    metrics = query.order_by(Metric.timestamp.desc()).offset(skip).limit(limit).all()
    return metrics

@router.get("/metrics/device/{device_id}/latest")
async def get_device_latest_metrics(
    device_id: int,
    metric_types: Optional[str] = None,
    db: Session = Depends(get_db)
):
    # Verify device exists
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    query = db.query(Metric).filter(Metric.device_id == device_id)
    
    if metric_types:
        types_list = metric_types.split(',')
        query = query.filter(Metric.metric_type.in_(types_list))
    
    # Get latest metric for each metric name
    latest_metrics = {}
    metrics = query.order_by(Metric.timestamp.desc()).all()
    
    for metric in metrics:
        if metric.metric_name not in latest_metrics:
            latest_metrics[metric.metric_name] = metric
    
    return {
        "device_id": device_id,
        "device_name": device.name,
        "latest_metrics": list(latest_metrics.values()),
        "timestamp": datetime.utcnow()
    }

@router.get("/metrics/device/{device_id}/history/{metric_name}")
async def get_metric_history(
    device_id: int,
    metric_name: str,
    hours: int = 24,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    # Verify device exists
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    time_threshold = datetime.utcnow() - timedelta(hours=hours)
    
    metrics = db.query(Metric).filter(
        Metric.device_id == device_id,
        Metric.metric_name == metric_name,
        Metric.timestamp >= time_threshold
    ).order_by(Metric.timestamp.desc()).limit(limit).all()
    
    return {
        "device_id": device_id,
        "metric_name": metric_name,
        "metrics": metrics,
        "time_range_hours": hours
    }

@router.get("/metrics/summary")
async def get_metrics_summary(
    device_id: Optional[int] = None,
    hours: int = 1,
    db: Session = Depends(get_db)
):
    time_threshold = datetime.utcnow() - timedelta(hours=hours)
    query = db.query(Metric).filter(Metric.timestamp >= time_threshold)
    
    if device_id:
        query = query.filter(Metric.device_id == device_id)
    
    metrics = query.all()
    
    # Group by metric type and calculate averages
    summary = {}
    for metric in metrics:
        key = f"{metric.metric_type}_{metric.metric_name}"
        if key not in summary:
            summary[key] = {
                "metric_type": metric.metric_type,
                "metric_name": metric.metric_name,
                "count": 0,
                "values": [],
                "unit": metric.unit
            }
        
        summary[key]["count"] += 1
        summary[key]["values"].append(metric.value)
    
    # Calculate statistics
    for key, data in summary.items():
        values = data["values"]
        if values:
            data["avg"] = sum(values) / len(values)
            data["min"] = min(values)
            data["max"] = max(values)
            data["latest"] = values[0]  # Already ordered by timestamp desc
        del data["values"]
    
    return {
        "summary": list(summary.values()),
        "time_range_hours": hours,
        "device_id": device_id
    }
