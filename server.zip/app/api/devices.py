from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime

from app.main import get_db
from app.models.device import Device
from app.models.metric import Metric

router = APIRouter()

# Pydantic models
class DeviceBase(BaseModel):
    name: str
    hostname: str
    ip_address: str
    mac_address: Optional[str] = None
    os_type: Optional[str] = None
    os_version: Optional[str] = None
    description: Optional[str] = None
    tags: Optional[str] = None

class DeviceCreate(DeviceBase):
    agent_version: Optional[str] = None
    collection_interval: int = 30

class DeviceUpdate(BaseModel):
    name: Optional[str] = None
    hostname: Optional[str] = None
    ip_address: Optional[str] = None
    mac_address: Optional[str] = None
    os_type: Optional[str] = None
    os_version: Optional[str] = None
    agent_version: Optional[str] = None
    collection_interval: Optional[int] = None
    description: Optional[str] = None
    tags: Optional[str] = None
    enabled_metrics: Optional[str] = None

class DeviceResponse(DeviceBase):
    id: int
    agent_version: Optional[str]
    is_online: bool
    last_seen: Optional[datetime]
    collection_interval: int
    enabled_metrics: Optional[str]
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True

class DeviceStatus(BaseModel):
    device_id: int
    is_online: bool
    last_seen: Optional[datetime]

# Endpoints
@router.post("/devices/", response_model=DeviceResponse, status_code=status.HTTP_201_CREATED)
async def create_device(device: DeviceCreate, db: Session = Depends(get_db)):
    # Check if device with same hostname or IP already exists
    existing = db.query(Device).filter(
        (Device.hostname == device.hostname) | (Device.ip_address == device.ip_address)
    ).first()
    
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Device with this hostname or IP already exists"
        )
    
    db_device = Device(**device.dict())
    db.add(db_device)
    db.commit()
    db.refresh(db_device)
    return db_device

@router.get("/devices/", response_model=List[DeviceResponse])
async def get_devices(
    skip: int = 0,
    limit: int = 100,
    online_only: bool = False,
    db: Session = Depends(get_db)
):
    query = db.query(Device)
    
    if online_only:
        query = query.filter(Device.is_online == True)
    
    devices = query.offset(skip).limit(limit).all()
    return devices

@router.get("/devices/{device_id}", response_model=DeviceResponse)
async def get_device(device_id: int, db: Session = Depends(get_db)):
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    return device

@router.put("/devices/{device_id}", response_model=DeviceResponse)
async def update_device(
    device_id: int,
    device_update: DeviceUpdate,
    db: Session = Depends(get_db)
):
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    update_data = device_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(device, field, value)
    
    db.commit()
    db.refresh(device)
    return device

@router.delete("/devices/{device_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_device(device_id: int, db: Session = Depends(get_db)):
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    # Delete associated metrics
    db.query(Metric).filter(Metric.device_id == device_id).delete()
    
    db.delete(device)
    db.commit()

@router.post("/devices/{device_id}/heartbeat")
async def device_heartbeat(
    device_id: int,
    db: Session = Depends(get_db)
):
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    device.is_online = True
    device.last_seen = datetime.utcnow()
    db.commit()
    
    return {"status": "ok", "message": "Heartbeat received"}

@router.get("/devices/{device_id}/status")
async def get_device_status(device_id: int, db: Session = Depends(get_db)):
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    # Get latest metrics
    latest_metrics = db.query(Metric).filter(
        Metric.device_id == device_id
    ).order_by(Metric.timestamp.desc()).limit(10).all()
    
    return {
        "device": DeviceResponse.from_orm(device),
        "latest_metrics": latest_metrics,
        "status": "online" if device.is_online else "offline"
    }
