from sqlalchemy import Column, Integer, String, DateTime, Float, ForeignKey, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func

Base = declarative_base()

class Metric(Base):
    __tablename__ = "metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False, index=True)
    
    # Metric identification
    metric_name = Column(String(100), nullable=False, index=True)
    metric_type = Column(String(50), nullable=False)  # cpu, memory, disk, network, custom
    
    # Values
    value = Column(Float, nullable=False)
    unit = Column(String(20), nullable=True)  # %, MB, GB, etc.
    
    # Additional data
    metadata = Column(Text, nullable=True)  # JSON string for additional context
    
    # Timestamps
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    def __repr__(self):
        return f"<Metric(device_id={self.device_id}, name={self.metric_name}, value={self.value})>"
