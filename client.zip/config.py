import os
import yaml
from typing import Dict, Any, Optional

class ClientConfig:
    def __init__(self, config_file: str = "config.yaml"):
        self.config_file = config_file
        self.config = self.load_config()
    
    def load_config(self) -> Dict[str, Any]:
        default_config = {
            "server": {
                "url": "http://localhost:8000",
                "api_prefix": "/api/v1",
                "timeout": 30
            },
            "device": {
                "name": os.uname().nodename,
                "collection_interval": 30,
                "enabled_metrics": ["cpu", "memory", "disk", "network"]
            },
            "metrics": {
                "cpu": {
                    "enabled": True,
                    "interval": 30
                },
                "memory": {
                    "enabled": True,
                    "interval": 30
                },
                "disk": {
                    "enabled": True,
                    "interval": 60,
                    "paths": ["/"]
                },
                "network": {
                    "enabled": True,
                    "interval": 30
                },
                "processes": {
                    "enabled": False,
                    "interval": 60
                }
            },
            "logging": {
                "level": "INFO",
                "file": "qwarktracker.log"
            }
        }
        
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    user_config = yaml.safe_load(f)
                    # Merge with defaults
                    default_config.update(user_config)
            except Exception as e:
                print(f"Error loading config file: {e}")
        
        return default_config
    
    def get(self, key: str, default: Any = None) -> Any:
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def save_config(self):
        try:
            with open(self.config_file, 'w') as f:
                yaml.dump(self.config, f, default_flow_style=False)
        except Exception as e:
            print(f"Error saving config file: {e}")

config = ClientConfig()
