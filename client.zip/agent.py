#!/usr/bin/env python3

import os
import sys
import time
import logging
import requests
import platform
import socket
import uuid
import json
from typing import Dict, Any, List
from datetime import datetime

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import config
from collectors import CPUCollector, MemoryCollector, DiskCollector, NetworkCollector, SystemCollector

class QwarkTrackerAgent:
    def __init__(self):
        self.setup_logging()
        self.logger = logging.getLogger(__name__)
        
        # Server configuration
        self.server_url = config.get('server.url', 'http://localhost:8000')
        self.api_prefix = config.get('server.api_prefix', '/api/v1')
        self.timeout = config.get('server.timeout', 30)
        
        # Device configuration
        self.device_name = config.get('device.name', platform.uname().nodename)
        self.collection_interval = config.get('device.collection_interval', 30)
        self.enabled_metrics = config.get('device.enabled_metrics', ['cpu', 'memory', 'disk', 'network'])
        
        # Initialize collectors
        self.collectors = self._initialize_collectors()
        
        # Device info
        self.device_info = self._get_device_info()
        self.device_id = None
        
        # Session for HTTP requests
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': f'QwarkTracker-Agent/{platform.system()}',
            'Content-Type': 'application/json'
        })
    
    def setup_logging(self):
        """Setup logging configuration"""
        log_level = config.get('logging.level', 'INFO')
        log_file = config.get('logging.file', 'qwarktracker.log')
        
        logging.basicConfig(
            level=getattr(logging, log_level.upper()),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(sys.stdout)
            ]
        )
    
    def _initialize_collectors(self) -> Dict[str, Any]:
        """Initialize metric collectors based on configuration"""
        collectors = {}
        
        if 'cpu' in self.enabled_metrics:
            collectors['cpu'] = CPUCollector(config.get('metrics.cpu', {}))
        
        if 'memory' in self.enabled_metrics:
            collectors['memory'] = MemoryCollector(config.get('metrics.memory', {}))
        
        if 'disk' in self.enabled_metrics:
            collectors['disk'] = DiskCollector(config.get('metrics.disk', {}))
        
        if 'network' in self.enabled_metrics:
            collectors['network'] = NetworkCollector(config.get('metrics.network', {}))
        
        if 'system' in self.enabled_metrics:
            collectors['system'] = SystemCollector(config.get('metrics.system', {}))
        
        return collectors
    
    def _get_device_info(self) -> Dict[str, Any]:
        """Get device information"""
        try:
            hostname = socket.gethostname()
            ip_address = socket.gethostbyname(hostname)
        except socket.gaierror:
            hostname = platform.uname().nodename
            ip_address = '127.0.0.1'
        
        # Try to get MAC address
        mac_address = None
        try:
            mac = uuid.getnode()
            mac_address = ':'.join(['{:02x}'.format((mac >> elements) & 0xff) for elements in range(0,2*6,2)][::-1])
        except:
            pass
        
        return {
            'name': self.device_name,
            'hostname': hostname,
            'ip_address': ip_address,
            'mac_address': mac_address,
            'os_type': platform.system(),
            'os_version': platform.release(),
            'agent_version': '1.0.0',
            'collection_interval': self.collection_interval,
            'enabled_metrics': json.dumps(self.enabled_metrics)
        }
    
    def _make_api_request(self, method: str, endpoint: str, data: Dict[str, Any] = None) -> Dict[str, Any]:
        """Make HTTP request to API"""
        url = f"{self.server_url}{self.api_prefix}{endpoint}"
        
        try:
            if method.upper() == 'GET':
                response = self.session.get(url, timeout=self.timeout)
            elif method.upper() == 'POST':
                response = self.session.post(url, json=data, timeout=self.timeout)
            elif method.upper() == 'PUT':
                response = self.session.put(url, json=data, timeout=self.timeout)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            
            if response.content:
                return response.json()
            else:
                return {}
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"API request failed: {e}")
            raise
    
    def register_device(self) -> bool:
        """Register device with the server"""
        try:
            # First try to find existing device by hostname or IP
            devices_response = self._make_api_request('GET', '/devices/')
            devices = devices_response.get('data', devices_response) if isinstance(devices_response, dict) else devices_response
            
            existing_device = None
            for device in devices:
                if (device.get('hostname') == self.device_info['hostname'] or 
                    device.get('ip_address') == self.device_info['ip_address']):
                    existing_device = device
                    break
            
            if existing_device:
                self.device_id = existing_device['id']
                self.logger.info(f"Found existing device: {self.device_id}")
                
                # Update device info
                self._make_api_request('PUT', f'/devices/{self.device_id}', self.device_info)
                return True
            else:
                # Create new device
                device_response = self._make_api_request('POST', '/devices/', self.device_info)
                self.device_id = device_response['id']
                self.logger.info(f"Registered new device: {self.device_id}")
                return True
                
        except Exception as e:
            self.logger.error(f"Failed to register device: {e}")
            return False
    
    def send_heartbeat(self) -> bool:
        """Send heartbeat to server"""
        if not self.device_id:
            return False
        
        try:
            self._make_api_request('POST', f'/devices/{self.device_id}/heartbeat')
            return True
        except Exception as e:
            self.logger.error(f"Failed to send heartbeat: {e}")
            return False
    
    def collect_metrics(self) -> List[Dict[str, Any]]:
        """Collect metrics from all enabled collectors"""
        all_metrics = []
        
        for collector_name, collector in self.collectors.items():
            try:
                metrics = collector.collect()
                all_metrics.extend(metrics)
                self.logger.debug(f"Collected {len(metrics)} metrics from {collector_name}")
            except Exception as e:
                self.logger.error(f"Failed to collect metrics from {collector_name}: {e}")
        
        return all_metrics
    
    def send_metrics(self, metrics: List[Dict[str, Any]]) -> bool:
        """Send metrics to server"""
        if not self.device_id or not metrics:
            return False
        
        try:
            # Prepare metrics batch
            batch_data = {
                'device_id': self.device_id,
                'metrics': metrics
            }
            
            self._make_api_request('POST', '/metrics/batch', batch_data)
            self.logger.debug(f"Sent {len(metrics)} metrics to server")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to send metrics: {e}")
            return False
    
    def run_collection_cycle(self):
        """Run one complete collection cycle"""
        self.logger.debug("Starting collection cycle")
        
        # Send heartbeat
        self.send_heartbeat()
        
        # Collect metrics
        metrics = self.collect_metrics()
        
        # Send metrics
        if metrics:
            self.send_metrics(metrics)
        
        self.logger.debug(f"Collection cycle completed. Sent {len(metrics)} metrics")
    
    def run(self):
        """Main agent loop"""
        self.logger.info("Starting QwarkTracker Agent")
        self.logger.info(f"Device: {self.device_name}")
        self.logger.info(f"Server: {self.server_url}")
        self.logger.info(f"Collection interval: {self.collection_interval}s")
        
        # Register device
        if not self.register_device():
            self.logger.error("Failed to register device. Exiting.")
            return
        
        self.logger.info(f"Device registered with ID: {self.device_id}")
        
        # Main loop
        try:
            while True:
                start_time = time.time()
                
                self.run_collection_cycle()
                
                # Calculate sleep time to maintain consistent interval
                elapsed = time.time() - start_time
                sleep_time = max(0, self.collection_interval - elapsed)
                
                if sleep_time > 0:
                    time.sleep(sleep_time)
                
        except KeyboardInterrupt:
            self.logger.info("Received interrupt signal. Shutting down.")
        except Exception as e:
            self.logger.error(f"Unexpected error: {e}")
        finally:
            self.logger.info("QwarkTracker Agent stopped")

def main():
    """Main entry point"""
    agent = QwarkTrackerAgent()
    agent.run()

if __name__ == '__main__':
    main()
