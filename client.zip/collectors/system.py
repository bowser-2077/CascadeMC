import platform
import socket
import psutil
import os
from typing import Dict, Any, List
from .base import BaseCollector

class SystemCollector(BaseCollector):
    def collect(self) -> List[Dict[str, Any]]:
        if not self.enabled:
            return []
        
        metrics = []
        
        # System uptime
        try:
            uptime_seconds = psutil.boot_time()
            current_time = psutil.time.time()
            uptime = current_time - uptime_seconds
            metrics.append(self.create_metric(
                "system_uptime_seconds",
                uptime,
                "seconds"
            ))
        except (AttributeError, OSError):
            pass
        
        # Process count
        try:
            process_count = len(psutil.pids())
            metrics.append(self.create_metric(
                "system_process_count",
                process_count,
                "processes"
            ))
        except (AttributeError, OSError):
            pass
        
        # Running process count
        try:
            running_processes = len([p for p in psutil.process_iter(['status']) 
                                   if p.info['status'] == psutil.STATUS_RUNNING])
            metrics.append(self.create_metric(
                "system_running_processes",
                running_processes,
                "processes"
            ))
        except (AttributeError, OSError):
            pass
        
        # System load (if available)
        try:
            load_avg = psutil.getloadavg()
            metrics.append(self.create_metric(
                "system_load_1min",
                load_avg[0],
                None,
                {"period": "1min"}
            ))
            metrics.append(self.create_metric(
                "system_load_5min",
                load_avg[1],
                None,
                {"period": "5min"}
            ))
            metrics.append(self.create_metric(
                "system_load_15min",
                load_avg[2],
                None,
                {"period": "15min"}
            ))
        except (AttributeError, OSError):
            pass
        
        # CPU temperature (if available)
        try:
            temps = psutil.sensors_temperatures()
            if temps:
                for name, entries in temps.items():
                    for entry in entries:
                        if entry.current:
                            metrics.append(self.create_metric(
                                f"temperature_{name}_{entry.label or 'temp'}",
                                entry.current,
                                "celsius",
                                {"sensor": name, "label": entry.label}
                            ))
        except (AttributeError, OSError):
            pass
        
        # Fan speeds (if available)
        try:
            fans = psutil.sensors_fans()
            if fans:
                for name, entries in fans.items():
                    for entry in entries:
                        if entry.current:
                            metrics.append(self.create_metric(
                                f"fan_{name}_{entry.label or 'fan'}",
                                entry.current,
                                "rpm",
                                {"sensor": name, "label": entry.label}
                            ))
        except (AttributeError, OSError):
            pass
        
        # Battery information (if available)
        try:
            battery = psutil.sensors_battery()
            if battery:
                metrics.append(self.create_metric(
                    "battery_percent",
                    battery.percent,
                    "%"
                ))
                if battery.power_plugged:
                    metrics.append(self.create_metric(
                        "battery_power_plugged",
                        1,
                        None
                    ))
                else:
                    metrics.append(self.create_metric(
                        "battery_power_plugged",
                        0,
                        None
                    ))
                
                if battery.secsleft not in (psutil.POWER_TIME_UNKNOWN, psutil.POWER_TIME_UNLIMITED):
                    metrics.append(self.create_metric(
                        "battery_time_left_seconds",
                        battery.secsleft,
                        "seconds"
                    ))
        except (AttributeError, OSError):
            pass
        
        return metrics
