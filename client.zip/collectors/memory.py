import psutil
from typing import Dict, Any, List
from .base import BaseCollector

class MemoryCollector(BaseCollector):
    def collect(self) -> List[Dict[str, Any]]:
        if not self.enabled:
            return []
        
        metrics = []
        
        # Virtual memory
        virtual_mem = psutil.virtual_memory()
        metrics.append(self.create_metric(
            "memory_total",
            virtual_mem.total,
            "bytes"
        ))
        metrics.append(self.create_metric(
            "memory_available",
            virtual_mem.available,
            "bytes"
        ))
        metrics.append(self.create_metric(
            "memory_used",
            virtual_mem.used,
            "bytes"
        ))
        metrics.append(self.create_metric(
            "memory_usage_percent",
            virtual_mem.percent,
            "%"
        ))
        metrics.append(self.create_metric(
            "memory_free",
            virtual_mem.free,
            "bytes"
        ))
        
        # Swap memory
        swap_mem = psutil.swap_memory()
        metrics.append(self.create_metric(
            "swap_total",
            swap_mem.total,
            "bytes"
        ))
        metrics.append(self.create_metric(
            "swap_used",
            swap_mem.used,
            "bytes"
        ))
        metrics.append(self.create_metric(
            "swap_free",
            swap_mem.free,
            "bytes"
        ))
        metrics.append(self.create_metric(
            "swap_usage_percent",
            swap_mem.percent,
            "%"
        ))
        
        return metrics
