import psutil
import os
from typing import Dict, Any, List
from .base import BaseCollector

class DiskCollector(BaseCollector):
    def collect(self) -> List[Dict[str, Any]]:
        if not self.enabled:
            return []
        
        metrics = []
        paths = self.config.get('paths', ['/'])
        
        for path in paths:
            try:
                # Disk usage for specific path
                disk_usage = psutil.disk_usage(path)
                mountpoint = self._get_mountpoint(path)
                
                metrics.append(self.create_metric(
                    f"disk_total_{mountpoint.replace('/', '_').strip('_') or 'root'}",
                    disk_usage.total,
                    "bytes",
                    {"mountpoint": mountpoint, "path": path}
                ))
                metrics.append(self.create_metric(
                    f"disk_used_{mountpoint.replace('/', '_').strip('_') or 'root'}",
                    disk_usage.used,
                    "bytes",
                    {"mountpoint": mountpoint, "path": path}
                ))
                metrics.append(self.create_metric(
                    f"disk_free_{mountpoint.replace('/', '_').strip('_') or 'root'}",
                    disk_usage.free,
                    "bytes",
                    {"mountpoint": mountpoint, "path": path}
                ))
                metrics.append(self.create_metric(
                    f"disk_usage_percent_{mountpoint.replace('/', '_').strip('_') or 'root'}",
                    (disk_usage.used / disk_usage.total) * 100,
                    "%",
                    {"mountpoint": mountpoint, "path": path}
                ))
            except (OSError, FileNotFoundError):
                # Path doesn't exist or can't access
                continue
        
        # Disk I/O statistics
        try:
            disk_io = psutil.disk_io_counters()
            if disk_io:
                metrics.append(self.create_metric(
                    "disk_read_count",
                    disk_io.read_count,
                    "operations"
                ))
                metrics.append(self.create_metric(
                    "disk_write_count",
                    disk_io.write_count,
                    "operations"
                ))
                metrics.append(self.create_metric(
                    "disk_read_bytes",
                    disk_io.read_bytes,
                    "bytes"
                ))
                metrics.append(self.create_metric(
                    "disk_write_bytes",
                    disk_io.write_bytes,
                    "bytes"
                ))
        except (AttributeError, OSError):
            pass
        
        # Per-disk I/O statistics
        try:
            disk_io_per_disk = psutil.disk_io_counters(perdisk=True)
            for disk_name, disk_stats in disk_io_per_disk.items():
                metrics.append(self.create_metric(
                    f"disk_{disk_name}_read_bytes",
                    disk_stats.read_bytes,
                    "bytes",
                    {"device": disk_name}
                ))
                metrics.append(self.create_metric(
                    f"disk_{disk_name}_write_bytes",
                    disk_stats.write_bytes,
                    "bytes",
                    {"device": disk_name}
                ))
        except (AttributeError, OSError):
            pass
        
        return metrics
    
    def _get_mountpoint(self, path: str) -> str:
        """Get the mount point for a given path"""
        try:
            partitions = psutil.disk_partitions()
            for partition in partitions:
                if path.startswith(partition.mountpoint):
                    return partition.mountpoint
        except (AttributeError, OSError):
            pass
        return path
