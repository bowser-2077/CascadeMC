from abc import ABC, abstractmethod
from typing import Dict, Any, List
from datetime import datetime

class BaseCollector(ABC):
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.enabled = config.get('enabled', True)
        self.interval = config.get('interval', 30)
    
    @abstractmethod
    def collect(self) -> List[Dict[str, Any]]:
        """
        Collect metrics and return a list of metric dictionaries
        Each metric dict should contain:
        - metric_name: str
        - metric_type: str
        - value: float
        - unit: str (optional)
        - metadata: dict (optional)
        """
        pass
    
    def create_metric(self, name: str, value: float, unit: str = None, metadata: Dict[str, Any] = None) -> Dict[str, Any]:
        """Create a standardized metric dictionary"""
        metric = {
            "metric_name": name,
            "metric_type": self.__class__.__name__.lower().replace('collector', ''),
            "value": value,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        if unit:
            metric["unit"] = unit
        
        if metadata:
            metric["metadata"] = metadata
        
        return metric
