import psutil
import socket
import netifaces
from typing import Dict, Any, List
from .base import BaseCollector

class NetworkCollector(BaseCollector):
    def collect(self) -> List[Dict[str, Any]]:
        if not self.enabled:
            return []
        
        metrics = []
        
        # Network I/O statistics
        try:
            net_io = psutil.net_io_counters()
            if net_io:
                metrics.append(self.create_metric(
                    "network_bytes_sent",
                    net_io.bytes_sent,
                    "bytes"
                ))
                metrics.append(self.create_metric(
                    "network_bytes_recv",
                    net_io.bytes_recv,
                    "bytes"
                ))
                metrics.append(self.create_metric(
                    "network_packets_sent",
                    net_io.packets_sent,
                    "packets"
                ))
                metrics.append(self.create_metric(
                    "network_packets_recv",
                    net_io.packets_recv,
                    "packets"
                ))
                metrics.append(self.create_metric(
                    "network_errin",
                    net_io.errin,
                    "errors"
                ))
                metrics.append(self.create_metric(
                    "network_errout",
                    net_io.errout,
                    "errors"
                ))
                metrics.append(self.create_metric(
                    "network_dropin",
                    net_io.dropin,
                    "packets"
                ))
                metrics.append(self.create_metric(
                    "network_dropout",
                    net_io.dropout,
                    "packets"
                ))
        except (AttributeError, OSError):
            pass
        
        # Per-interface network statistics
        try:
            net_io_per_nic = psutil.net_io_counters(pernic=True)
            for interface_name, net_stats in net_io_per_nic.items():
                # Skip loopback interfaces
                if interface_name.startswith('lo'):
                    continue
                
                metrics.append(self.create_metric(
                    f"network_{interface_name}_bytes_sent",
                    net_stats.bytes_sent,
                    "bytes",
                    {"interface": interface_name}
                ))
                metrics.append(self.create_metric(
                    f"network_{interface_name}_bytes_recv",
                    net_stats.bytes_recv,
                    "bytes",
                    {"interface": interface_name}
                ))
                metrics.append(self.create_metric(
                    f"network_{interface_name}_packets_sent",
                    net_stats.packets_sent,
                    "packets",
                    {"interface": interface_name}
                ))
                metrics.append(self.create_metric(
                    f"network_{interface_name}_packets_recv",
                    net_stats.packets_recv,
                    "packets",
                    {"interface": interface_name}
                ))
        except (AttributeError, OSError):
            pass
        
        # Network interface information
        try:
            interfaces = netifaces.interfaces()
            for interface in interfaces:
                if interface.startswith('lo'):
                    continue
                
                addrs = netifaces.ifaddresses(interface)
                
                # Get IPv4 address
                if netifaces.AF_INET in addrs:
                    ipv4_info = addrs[netifaces.AF_INET][0]
                    metrics.append(self.create_metric(
                        f"interface_{interface}_ipv4_configured",
                        1,
                        None,
                        {"interface": interface, "address": ipv4_info.get('addr')}
                    ))
                
                # Get IPv6 address
                if netifaces.AF_INET6 in addrs:
                    ipv6_info = addrs[netifaces.AF_INET6][0]
                    metrics.append(self.create_metric(
                        f"interface_{interface}_ipv6_configured",
                        1,
                        None,
                        {"interface": interface, "address": ipv6_info.get('addr')}
                    ))
                
                # Interface status (up/down)
                try:
                    is_up = netifaces.ifaddresses(interface) is not None
                    metrics.append(self.create_metric(
                        f"interface_{interface}_status",
                        1 if is_up else 0,
                        None,
                        {"interface": interface, "status": "up" if is_up else "down"}
                    ))
                except:
                    pass
        except (ImportError, AttributeError, OSError):
            # netifaces not available or error
            pass
        
        # Network connections count
        try:
            connections = psutil.net_connections()
            established_connections = [conn for conn in connections if conn.status == 'ESTABLISHED']
            listening_connections = [conn for conn in connections if conn.status == 'LISTEN']
            
            metrics.append(self.create_metric(
                "network_connections_total",
                len(connections),
                "connections"
            ))
            metrics.append(self.create_metric(
                "network_connections_established",
                len(established_connections),
                "connections"
            ))
            metrics.append(self.create_metric(
                "network_connections_listening",
                len(listening_connections),
                "connections"
            ))
        except (AttributeError, OSError):
            pass
        
        return metrics
