import psutil
from typing import Dict, Any, List
from .base import BaseCollector

class CPUCollector(BaseCollector):
    def collect(self) -> List[Dict[str, Any]]:
        if not self.enabled:
            return []
        
        metrics = []
        
        # CPU usage percentage
        cpu_percent = psutil.cpu_percent(interval=1)
        metrics.append(self.create_metric(
            "cpu_usage_percent",
            cpu_percent,
            "%",
            {"cores": psutil.cpu_count()}
        ))
        
        # CPU load averages (Linux/Unix)
        try:
            load_avg = psutil.getloadavg()
            metrics.append(self.create_metric(
                "cpu_load_1min",
                load_avg[0],
                None,
                {"period": "1min"}
            ))
            metrics.append(self.create_metric(
                "cpu_load_5min",
                load_avg[1],
                None,
                {"period": "5min"}
            ))
            metrics.append(self.create_metric(
                "cpu_load_15min",
                load_avg[2],
                None,
                {"period": "15min"}
            ))
        except (AttributeError, OSError):
            # Windows doesn't have getloadavg
            pass
        
        # Per-core CPU usage
        cpu_percent_per_core = psutil.cpu_percent(interval=1, percpu=True)
        for i, core_percent in enumerate(cpu_percent_per_core):
            metrics.append(self.create_metric(
                f"cpu_core_{i}_usage_percent",
                core_percent,
                "%",
                {"core": i}
            ))
        
        # CPU frequency
        try:
            cpu_freq = psutil.cpu_freq()
            if cpu_freq:
                metrics.append(self.create_metric(
                    "cpu_frequency_mhz",
                    cpu_freq.current,
                    "MHz",
                    {"min": cpu_freq.min, "max": cpu_freq.max}
                ))
        except (AttributeError, OSError):
            pass
        
        # CPU times
        cpu_times = psutil.cpu_times()
        metrics.append(self.create_metric(
            "cpu_time_user",
            cpu_times.user,
            "seconds"
        ))
        metrics.append(self.create_metric(
            "cpu_time_system",
            cpu_times.system,
            "seconds"
        ))
        metrics.append(self.create_metric(
            "cpu_time_idle",
            cpu_times.idle,
            "seconds"
        ))
        
        return metrics
